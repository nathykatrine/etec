﻿<!DOCTYPE HTML>
<html lang="pt-br">

<head>
	<meta charset="utf-8">
	<link rel="stylesheet" href="imagem.css">
	<title>Form </title>
</head>

<body>
	<?php

	include "conect.php";
	$rm = $_POST['rm'];
	$dados = mysqli_query($sql, "SELECT * FROM imagem where rm=$rm");
	while ($coluna = mysqli_fetch_array($dados)) {
		$nome = $coluna['nome'];
		$foto = $coluna['foto'];
		echo "
    <div id='princ'>

		<texto>Bem vindo: $nome</texto>
		<img src=$foto  id='avatar'>
	</div>";
	}
    

	?>
<form action="trocar.php" enctype="multipart/form-data" method="post">
<input name="rm" type="hidden" value="<?php echo$rm?>">
<input name="foto" type="hidden" value="<?php echo$foto?>">
Trocar Avatar: <input name="userfile" type="file" /><br>
<input type="submit" value="Enviar" />
</body>

</html>