<?php
include "conect.php";
$rm = $_POST['rm'];
/* $pasta="imagens/";
$ext= ".jpg"; */
$dados = mysqli_query($sql, "SELECT * FROM imagem where rm=$rm");
while ($coluna = mysqli_fetch_array($dados)) {
    $foto = $coluna['foto'];
}
unlink($foto);
/* unlink($pasta . $rm . $ext); */

echo "imagem apagada";
